function ProtectedRoute({ children, allowedRole }) {
  const token = localStorage.getItem("token");
  const role = localStorage.getItem("role");

  if (!token) {
    return <Navigate to="/login" replace />;
  }

  if (allowedRole && role?.toUpperCase() !== allowedRole.toUpperCase()) {
    return <Navigate to="/login" replace />;
  }

  return children;
}
