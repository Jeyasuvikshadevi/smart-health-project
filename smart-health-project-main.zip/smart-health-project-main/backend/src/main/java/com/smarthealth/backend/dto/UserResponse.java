package com.smarthealth.backend.dto;

import java.util.Set;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class UserResponse {

    private Long id;
    private String email;
    private String provider;
    private boolean enabled;
    private String role;

}
